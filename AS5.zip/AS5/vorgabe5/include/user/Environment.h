#ifndef UserEnvironment_h
#define UserEnvironment_h

#include "system/Console.h"
#include "io/PrintStream.h"
extern Console console;
extern PrintStream out;

#endif
