#include "thread/Scheduler.h"
#include "io/PrintStream.h"
#include "device/CgaChannel.h"
#include "thread/ActivityScheduler.h"
extern ActivityScheduler scheduler;

extern CgaChannel cga;
extern PrintStream out;

//Einfuegen in Ready Liste
void Scheduler::schedule(Schedulable* sched){
    
    IntLock lock;
    readylist.enqueue(sched);//Objekt schon erstellt in header(void Methode)
};
//Entfernen eines Elements aus der Ready Liste
void Scheduler::remove(Schedulable* sched){
    
    IntLock lock;
    readylist.remove(sched);
};
//Aktiviert das vorderste Element
void Scheduler::reschedule(){
    
    IntLock lock;
    // erstes Element wird an die Methode activate in ActivityScheduler uebergeben
    activate((Schedulable*) readylist.dequeue());

};
//Zeitscheiben Ueberpruefung
void Scheduler::checkSlice(){

	IntLock lock;
	Schedulable* actuellActivity = (Activity*) scheduler.active();
	if((actuellActivity->quantum()!=0)){
		actuellActivity->quantum(actuellActivity->quantum()-1); // wenn Quantum bei akutellen Aktiviutat nicht 0 ist, dann wird um 1 reduziert
	}
	else{
		actuellActivity->quantum(actuellActivity->quantumOrginal()); // wird quantum wieder gesetzt im Bezug auf dem urspruglichen Wert
		reschedule();
	}
};
